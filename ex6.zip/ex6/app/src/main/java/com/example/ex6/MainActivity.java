package com.example.ex6;

import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    MediaPlayer m1;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button b1=(Button) findViewById(R.id.button);
        ImageView img=(ImageView) findViewById(R.id.imageView);
        m1= MediaPlayer.create(MainActivity.this,R.raw.aud);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        img.post(new Runnable() {
                            @Override
                            public void run() {
                                AnimationDrawable a= new AnimationDrawable();
                                a.addFrame(getResources().getDrawable(R.drawable.img1),500);
                                a.addFrame(getResources().getDrawable(R.drawable.img2),500);
                                a.addFrame(getResources().getDrawable(R.drawable.img3),500);
                                a.addFrame(getResources().getDrawable(R.drawable.img4),500);
                                a.addFrame(getResources().getDrawable(R.drawable.img5),500);

                                a.setOneShot(false);
                                img.setBackgroundDrawable(a);
                                a.start();
                            }
                        });
                    }
                }).start();
                new Thread((new Runnable() {
                    @Override
                    public void run() {
                        img.post(new Runnable() {
                            @Override
                            public void run() {
                                m1.start();
                            }
                        });
                    }
                })) ;
            }
        });
    }
}



